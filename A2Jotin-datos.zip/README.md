# A2Jotin-datos

Repositorio público de datos estructurados de A2J para uso técnico y lectura por sistemas de IA (GPT personalizado, automatizaciones y formación interna).
