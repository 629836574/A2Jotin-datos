# PRIVACIDAD Y USO DE DATOS

Este repositorio tiene como único propósito facilitar el acceso a datos estructurados para uso técnico en materia de protección contra incendios.

No se recogen ni almacenan datos personales. No se instalan cookies.

Contacto: a2jcorreo@gmail.com
